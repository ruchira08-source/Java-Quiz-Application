Java Quiz Application

This is a Java Swing-based Quiz Application.
It includes multiple-choice questions, a timer,
question navigation, and a result page.

How to Run:
1. Open the project folder in VS Code.
2. Open the terminal.
3. Run: javac QuizApplication.java
4. Run: java QuizApplication